const SETTINGS = {
	reduxLogging: true
};

export default SETTINGS;
